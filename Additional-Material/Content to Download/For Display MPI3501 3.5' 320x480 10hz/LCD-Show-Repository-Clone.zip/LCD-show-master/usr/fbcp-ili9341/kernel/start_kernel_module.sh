echo Starting kernel module bcm2835_spi_display.ko
sudo insmod bcm2835_spi_display.ko

