#!/bin/bash

platform=`getconf LONG_BIT`

if [ "$1" = "install" ]
then
    if [ $platform = '64' ]
    then
        sudo chmod 777 brightness64bit brightness64bit.desktop
        sudo cp brightness64bit brightness64bit.desktop brightness.png /usr/share/applications/
        # rm install.sh
        # echo "move brightness file to /usr/share/application/"
    else
        sudo chmod 777 brightness32bit brightness32bit.desktop
        sudo cp brightness32bit brightness32bit.desktop brightness.png /usr/share/applications/
        # rm install.sh
        # echo "move brightness file to /usr/share/application/"
    fi
elif [ "$1" = "uninstall" ]
then
    if [ $platform = '64' ]
    then
        cd /usr/share/applications/
        sudo rm brightness64bit brightness64bit.desktop brightness.png
        cd ~
        # echo "remove brightness files in /usr/share/applications/"
    else
        cd /usr/share/applications/
        sudo rm brightness32bit brightness32bit.desktop brightness.png
        cd ~
    fi
else
    if [ $platform = '64' ]
    then
        sudo chmod 777 brightness64bit brightness64bit.desktop
        sudo cp brightness64bit brightness64bit.desktop brightness.png /usr/share/applications/
        # rm install.sh
        # echo "move brightness file to /usr/share/application/"
    else
        sudo chmod 777 brightness32bit brightness32bit.desktop
        sudo cp brightness32bit brightness32bit.desktop brightness.png /usr/share/applications/
        # rm install.sh
        # echo "move brightness file to /usr/share/application/"
    fi
fi
